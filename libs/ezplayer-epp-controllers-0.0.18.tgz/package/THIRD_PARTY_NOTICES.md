# Third-party notices

This package is licensed AGPL-3.0-only (see `package.json`). It incorporates
material from the xLights project as described below.

## xLights

- Project: https://github.com/xLightsSequencer/xLights
- Copyright: the xLights authors
- License: GPL-3.0 (a copy is provided as `LICENSE.GPL-3.0.txt`)

**Verbatim material.** The controller capability files in
`assets/xcontrollers/*.xcontroller`, and their packed form
`src/base/assets/xcontrollers.json` (shipped inside the dist bundles), are
copied unmodified from xLights `resources/controllers/`. They remain under
GPL-3.0.

**Derived code.** Some of the code in this package — in particular the
controller configuration-upload logic in the drivers and the port-derivation
and pre-upload validation helpers — was developed with reference to, and in
parts derived from, the xLights controller sources
(`src-core/controllers/`). The controller protocols themselves were learned
from those sources and from the devices; this code is expected to diverge
from xLights over time. To the extent portions remain derivative of xLights
code, they are subject to the copyright of the xLights authors and may be
used under the GPL-3.0 in addition to this package's AGPL-3.0-only terms.

The GPL-3.0 and AGPL-3.0 each permit this combination (section 13 of both
licenses): the xLights-derived portions remain GPL-3.0, the rest of the
package is AGPL-3.0-only, and the combined work is conveyed under the terms
of both.
